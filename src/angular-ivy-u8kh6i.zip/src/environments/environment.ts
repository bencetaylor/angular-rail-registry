export const environment = {
  production: false,
  isMockEnabled: true,
};
