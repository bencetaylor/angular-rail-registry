export const environment = {
  production: true,
  isMockEnabled: false,
};
