import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wagon-update',
  templateUrl: './wagon-update.component.html',
  styleUrls: ['./wagon-update.component.css']
})
export class WagonUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}