import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wagon-create',
  templateUrl: './wagon-create.component.html',
  styleUrls: ['./wagon-create.component.css']
})
export class WagonCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}