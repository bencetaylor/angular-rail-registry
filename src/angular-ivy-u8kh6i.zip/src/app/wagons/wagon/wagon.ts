export class Wagon {
  id: number;
  serial: string;
  productionDate: string;
  trackNr: string;
  owner: string;
  siteId: number;
  status: boolean;
}
