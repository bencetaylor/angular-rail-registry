import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wagon-list',
  templateUrl: './wagon-list.component.html',
  styleUrls: ['./wagon-list.component.css']
})
export class WagonListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}