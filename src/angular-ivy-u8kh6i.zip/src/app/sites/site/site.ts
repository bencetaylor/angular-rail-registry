export class Site {
  id: number;
  name: string;
  owner: string;
  address: string;
  zip: number;
  status: boolean;
}
