import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-update',
  templateUrl: './site-update.component.html',
  styleUrls: ['./site-update.component.css']
})
export class SiteUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}